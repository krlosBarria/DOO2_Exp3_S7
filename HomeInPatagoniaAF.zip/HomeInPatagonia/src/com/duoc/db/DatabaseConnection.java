
package com.duoc.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 16-09-2024
 * @hora: 22:21:01
 * @asignatura: Desarrollo Orientado A Objetos II
 *
 */
public class DatabaseConnection {

public Connection obtenerConexion() {
        Connection connection = null;
        try {
            // Elimina la línea que carga manualmente el driver com.mysql.jdbc.Driver
            // cambia a com.mysql.cj.jdbc.Driver el cual; está cargado automaticamente
            // mediante el Service Provider Interface (SPI)
            // Class.forName("com.mysql.jdbc.Driver");
            
            // Establece la conexión usando la URL del JDBC
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviesdb", "root", "eddie");
            System.out.println("Conexión exitosa");
        } catch (SQLException e) {
            System.out.println("Error de conexión" + e.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return connection;
    }
}
