
package com.duoc.Model;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 16-09-2024
 * @hora: 22:42:59
 * @asignatura: Desarrollo Orientado A Objetos II
 *
 */
public class Pelicula {
    
    private int idPelicula;
    private String titulo;
    private String directo;
    private int año;
    private int duracion;
    private String genero;

    public Pelicula() {
    }

    public Pelicula(int idPelicula, String titulo, String directo, int año, int duracion, String genero) {
        this.idPelicula = idPelicula;
        this.titulo = titulo;
        this.directo = directo;
        this.año = año;
        this.duracion = duracion;
        this.genero = genero;
    }

    public int getIdPelicula() {
        return idPelicula;
    }

    public void setIdPelicula(int idPelicula) {
        this.idPelicula = idPelicula;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDirecto() {
        return directo;
    }

    public void setDirecto(String directo) {
        this.directo = directo;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
}
