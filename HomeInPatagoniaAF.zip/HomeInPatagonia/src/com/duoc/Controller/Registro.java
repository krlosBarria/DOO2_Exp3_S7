
package com.duoc.Controller;

import com.duoc.Model.Pelicula;
import com.duoc.db.DatabaseConnection;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 16-09-2024
 * @hora: 23:16:23
 * @asignatura: Desarrollo Orientado A Objetos II
 *
 */
public class Registro {

    public List<Pelicula> buscarTodos() {
        List<Pelicula> lista = new ArrayList<>();
                
        try {
            DatabaseConnection conexion = new DatabaseConnection();
            Connection cnx = conexion.obtenerConexion();
            
            String query = "SELECT idPelicula, titulo, director, año, duracion, genero FROM movie order by titulo";
            PreparedStatement stmt = cnx.prepareStatement(query);
            
        } catch (SQLException ex) {
            System.out.println("Error SQL Peliculas "+ ex.getMessage());
        } catch (Exception ex) {
            System.out.println("Erro al listar Peliculas");
        }
        return lista;
    }
}
